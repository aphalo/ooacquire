﻿namespace InternalTrigger
{
    partial class InternalTrigger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDiscoverSpectrometers = new System.Windows.Forms.Button();
            this.lstSpectrometersDiscovered = new System.Windows.Forms.ListBox();
            this.lblNumberOfSpectrometers = new System.Windows.Forms.Label();
            this.lblSpectrometerSelected = new System.Windows.Forms.Label();
            this.lblIsFeatureSupported = new System.Windows.Forms.Label();
            this.txtSetInternalTriggerPeriodMicros = new System.Windows.Forms.TextBox();
            this.txtGetInternalTriggerPeriodMicros = new System.Windows.Forms.TextBox();
            this.txtGetInternalTriggerPeriodMinimum = new System.Windows.Forms.TextBox();
            this.lblGetInternalTriggerPeriodMinimum = new System.Windows.Forms.Label();
            this.txtGetInternalTriggerPeriodMaximum = new System.Windows.Forms.TextBox();
            this.lblGetInternalTriggerPeriodMaximum = new System.Windows.Forms.Label();
            this.txtGetInternalTriggerPeriodIncrement = new System.Windows.Forms.TextBox();
            this.lblGetInternalTriggerPeriodIncrement = new System.Windows.Forms.Label();
            this.btnSetInternalTriggerPeriodMicros = new System.Windows.Forms.Button();
            this.btnGetInternalTriggerPeriodMicros = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnDiscoverSpectrometers
            // 
            this.btnDiscoverSpectrometers.Location = new System.Drawing.Point(42, 33);
            this.btnDiscoverSpectrometers.Name = "btnDiscoverSpectrometers";
            this.btnDiscoverSpectrometers.Size = new System.Drawing.Size(377, 46);
            this.btnDiscoverSpectrometers.TabIndex = 0;
            this.btnDiscoverSpectrometers.Text = "Discover Spectrometers";
            this.btnDiscoverSpectrometers.UseVisualStyleBackColor = true;
            this.btnDiscoverSpectrometers.Click += new System.EventHandler(this.btnDiscoverSpectrometers_Click);
            // 
            // lstSpectrometersDiscovered
            // 
            this.lstSpectrometersDiscovered.FormattingEnabled = true;
            this.lstSpectrometersDiscovered.ItemHeight = 20;
            this.lstSpectrometersDiscovered.Location = new System.Drawing.Point(42, 86);
            this.lstSpectrometersDiscovered.Name = "lstSpectrometersDiscovered";
            this.lstSpectrometersDiscovered.Size = new System.Drawing.Size(377, 84);
            this.lstSpectrometersDiscovered.TabIndex = 1;
            this.lstSpectrometersDiscovered.SelectedIndexChanged += new System.EventHandler(this.lstSpectrometersDiscovered_SelectedIndexChanged);
            // 
            // lblNumberOfSpectrometers
            // 
            this.lblNumberOfSpectrometers.AutoSize = true;
            this.lblNumberOfSpectrometers.Location = new System.Drawing.Point(42, 10);
            this.lblNumberOfSpectrometers.Name = "lblNumberOfSpectrometers";
            this.lblNumberOfSpectrometers.Size = new System.Drawing.Size(282, 20);
            this.lblNumberOfSpectrometers.TabIndex = 2;
            this.lblNumberOfSpectrometers.Text = "Number Of Spectrometers Discovered:";
            // 
            // lblSpectrometerSelected
            // 
            this.lblSpectrometerSelected.AutoSize = true;
            this.lblSpectrometerSelected.Location = new System.Drawing.Point(42, 177);
            this.lblSpectrometerSelected.Name = "lblSpectrometerSelected";
            this.lblSpectrometerSelected.Size = new System.Drawing.Size(177, 20);
            this.lblSpectrometerSelected.TabIndex = 3;
            this.lblSpectrometerSelected.Text = "Spectrometer Selected:";
            // 
            // lblIsFeatureSupported
            // 
            this.lblIsFeatureSupported.AutoSize = true;
            this.lblIsFeatureSupported.Location = new System.Drawing.Point(42, 207);
            this.lblIsFeatureSupported.Name = "lblIsFeatureSupported";
            this.lblIsFeatureSupported.Size = new System.Drawing.Size(281, 20);
            this.lblIsFeatureSupported.TabIndex = 4;
            this.lblIsFeatureSupported.Text = "Is Internal Trigger Feature Supported?";
            // 
            // txtSetInternalTriggerPeriodMicros
            // 
            this.txtSetInternalTriggerPeriodMicros.Location = new System.Drawing.Point(319, 375);
            this.txtSetInternalTriggerPeriodMicros.Name = "txtSetInternalTriggerPeriodMicros";
            this.txtSetInternalTriggerPeriodMicros.Size = new System.Drawing.Size(100, 26);
            this.txtSetInternalTriggerPeriodMicros.TabIndex = 6;
            this.txtSetInternalTriggerPeriodMicros.Visible = false;
            // 
            // txtGetInternalTriggerPeriodMicros
            // 
            this.txtGetInternalTriggerPeriodMicros.Location = new System.Drawing.Point(319, 334);
            this.txtGetInternalTriggerPeriodMicros.Name = "txtGetInternalTriggerPeriodMicros";
            this.txtGetInternalTriggerPeriodMicros.Size = new System.Drawing.Size(100, 26);
            this.txtGetInternalTriggerPeriodMicros.TabIndex = 8;
            this.txtGetInternalTriggerPeriodMicros.Visible = false;
            // 
            // txtGetInternalTriggerPeriodMinimum
            // 
            this.txtGetInternalTriggerPeriodMinimum.Location = new System.Drawing.Point(319, 236);
            this.txtGetInternalTriggerPeriodMinimum.Name = "txtGetInternalTriggerPeriodMinimum";
            this.txtGetInternalTriggerPeriodMinimum.Size = new System.Drawing.Size(100, 26);
            this.txtGetInternalTriggerPeriodMinimum.TabIndex = 10;
            this.txtGetInternalTriggerPeriodMinimum.Visible = false;
            // 
            // lblGetInternalTriggerPeriodMinimum
            // 
            this.lblGetInternalTriggerPeriodMinimum.AutoSize = true;
            this.lblGetInternalTriggerPeriodMinimum.Location = new System.Drawing.Point(26, 239);
            this.lblGetInternalTriggerPeriodMinimum.Name = "lblGetInternalTriggerPeriodMinimum";
            this.lblGetInternalTriggerPeriodMinimum.Size = new System.Drawing.Size(297, 20);
            this.lblGetInternalTriggerPeriodMinimum.TabIndex = 9;
            this.lblGetInternalTriggerPeriodMinimum.Text = "Get Internal Trigger Period Minimum (µs):";
            this.lblGetInternalTriggerPeriodMinimum.Visible = false;
            // 
            // txtGetInternalTriggerPeriodMaximum
            // 
            this.txtGetInternalTriggerPeriodMaximum.Location = new System.Drawing.Point(319, 265);
            this.txtGetInternalTriggerPeriodMaximum.Name = "txtGetInternalTriggerPeriodMaximum";
            this.txtGetInternalTriggerPeriodMaximum.Size = new System.Drawing.Size(100, 26);
            this.txtGetInternalTriggerPeriodMaximum.TabIndex = 12;
            this.txtGetInternalTriggerPeriodMaximum.Visible = false;
            // 
            // lblGetInternalTriggerPeriodMaximum
            // 
            this.lblGetInternalTriggerPeriodMaximum.AutoSize = true;
            this.lblGetInternalTriggerPeriodMaximum.Location = new System.Drawing.Point(22, 268);
            this.lblGetInternalTriggerPeriodMaximum.Name = "lblGetInternalTriggerPeriodMaximum";
            this.lblGetInternalTriggerPeriodMaximum.Size = new System.Drawing.Size(301, 20);
            this.lblGetInternalTriggerPeriodMaximum.TabIndex = 11;
            this.lblGetInternalTriggerPeriodMaximum.Text = "Get Internal Trigger Period Maximum (µs):";
            this.lblGetInternalTriggerPeriodMaximum.Visible = false;
            // 
            // txtGetInternalTriggerPeriodIncrement
            // 
            this.txtGetInternalTriggerPeriodIncrement.Location = new System.Drawing.Point(319, 291);
            this.txtGetInternalTriggerPeriodIncrement.Name = "txtGetInternalTriggerPeriodIncrement";
            this.txtGetInternalTriggerPeriodIncrement.Size = new System.Drawing.Size(100, 26);
            this.txtGetInternalTriggerPeriodIncrement.TabIndex = 14;
            this.txtGetInternalTriggerPeriodIncrement.Visible = false;
            // 
            // lblGetInternalTriggerPeriodIncrement
            // 
            this.lblGetInternalTriggerPeriodIncrement.AutoSize = true;
            this.lblGetInternalTriggerPeriodIncrement.Location = new System.Drawing.Point(17, 294);
            this.lblGetInternalTriggerPeriodIncrement.Name = "lblGetInternalTriggerPeriodIncrement";
            this.lblGetInternalTriggerPeriodIncrement.Size = new System.Drawing.Size(306, 20);
            this.lblGetInternalTriggerPeriodIncrement.TabIndex = 13;
            this.lblGetInternalTriggerPeriodIncrement.Text = "Get Internal Trigger Period Increment (µs):";
            this.lblGetInternalTriggerPeriodIncrement.Visible = false;
            // 
            // btnSetInternalTriggerPeriodMicros
            // 
            this.btnSetInternalTriggerPeriodMicros.Location = new System.Drawing.Point(61, 371);
            this.btnSetInternalTriggerPeriodMicros.Name = "btnSetInternalTriggerPeriodMicros";
            this.btnSetInternalTriggerPeriodMicros.Size = new System.Drawing.Size(252, 34);
            this.btnSetInternalTriggerPeriodMicros.TabIndex = 15;
            this.btnSetInternalTriggerPeriodMicros.Text = "Set Internal Trigger Period (µs)";
            this.btnSetInternalTriggerPeriodMicros.UseVisualStyleBackColor = true;
            this.btnSetInternalTriggerPeriodMicros.Visible = false;
            this.btnSetInternalTriggerPeriodMicros.Click += new System.EventHandler(this.btnSetInternalTriggerPeriodMicros_Click);
            // 
            // btnGetInternalTriggerPeriodMicros
            // 
            this.btnGetInternalTriggerPeriodMicros.Location = new System.Drawing.Point(61, 330);
            this.btnGetInternalTriggerPeriodMicros.Name = "btnGetInternalTriggerPeriodMicros";
            this.btnGetInternalTriggerPeriodMicros.Size = new System.Drawing.Size(252, 35);
            this.btnGetInternalTriggerPeriodMicros.TabIndex = 16;
            this.btnGetInternalTriggerPeriodMicros.Text = "Get Internal Trigger Period (µs)";
            this.btnGetInternalTriggerPeriodMicros.UseVisualStyleBackColor = true;
            this.btnGetInternalTriggerPeriodMicros.Visible = false;
            this.btnGetInternalTriggerPeriodMicros.Click += new System.EventHandler(this.btnGetInternalTriggerPeriodMicros_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(46, 422);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 37);
            this.btnClear.TabIndex = 17;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(344, 422);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 37);
            this.btnExit.TabIndex = 18;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // InternalTrigger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 480);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnGetInternalTriggerPeriodMicros);
            this.Controls.Add(this.btnSetInternalTriggerPeriodMicros);
            this.Controls.Add(this.txtGetInternalTriggerPeriodIncrement);
            this.Controls.Add(this.lblGetInternalTriggerPeriodIncrement);
            this.Controls.Add(this.txtGetInternalTriggerPeriodMaximum);
            this.Controls.Add(this.lblGetInternalTriggerPeriodMaximum);
            this.Controls.Add(this.txtGetInternalTriggerPeriodMinimum);
            this.Controls.Add(this.lblGetInternalTriggerPeriodMinimum);
            this.Controls.Add(this.txtGetInternalTriggerPeriodMicros);
            this.Controls.Add(this.txtSetInternalTriggerPeriodMicros);
            this.Controls.Add(this.lblIsFeatureSupported);
            this.Controls.Add(this.lblSpectrometerSelected);
            this.Controls.Add(this.lblNumberOfSpectrometers);
            this.Controls.Add(this.lstSpectrometersDiscovered);
            this.Controls.Add(this.btnDiscoverSpectrometers);
            this.Name = "InternalTrigger";
            this.Text = "InternalTrigger";
            this.Load += new System.EventHandler(this.InternalTrigger_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDiscoverSpectrometers;
        private System.Windows.Forms.ListBox lstSpectrometersDiscovered;
        private System.Windows.Forms.Label lblNumberOfSpectrometers;
        private System.Windows.Forms.Label lblSpectrometerSelected;
        private System.Windows.Forms.Label lblIsFeatureSupported;
        private System.Windows.Forms.TextBox txtSetInternalTriggerPeriodMicros;
        private System.Windows.Forms.TextBox txtGetInternalTriggerPeriodMicros;
        private System.Windows.Forms.TextBox txtGetInternalTriggerPeriodMinimum;
        private System.Windows.Forms.Label lblGetInternalTriggerPeriodMinimum;
        private System.Windows.Forms.TextBox txtGetInternalTriggerPeriodMaximum;
        private System.Windows.Forms.Label lblGetInternalTriggerPeriodMaximum;
        private System.Windows.Forms.TextBox txtGetInternalTriggerPeriodIncrement;
        private System.Windows.Forms.Label lblGetInternalTriggerPeriodIncrement;
        private System.Windows.Forms.Button btnSetInternalTriggerPeriodMicros;
        private System.Windows.Forms.Button btnGetInternalTriggerPeriodMicros;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}