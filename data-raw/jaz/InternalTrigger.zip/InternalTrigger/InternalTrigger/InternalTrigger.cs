﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace InternalTrigger
{
    public partial class InternalTrigger : Form
    {
        int numberOfSpectrometers;
        int spectrometerIndex;
        OmniDriver.NETWrapper wrapper;
        OmniDriver.NETInternalTriggerWrapper internalTriggerWrapper;

        public InternalTrigger()
        {
            InitializeComponent();

            // Instantiate the wrapper object
            wrapper = new OmniDriver.NETWrapper();

            // Instantiate the InternalTriggerWrapper Interface
            internalTriggerWrapper = new OmniDriver.NETInternalTriggerWrapper();
        }

        // Discover attached Ocean Optics USB-connected spectrometers
        private void btnDiscoverSpectrometers_Click(object sender, EventArgs e)
        {
            btnDiscoverSpectrometers.Enabled = false;
            numberOfSpectrometers = wrapper.openAllSpectrometers();
             lblNumberOfSpectrometers.Text = "Number of Spectrometers Discovered: " + numberOfSpectrometers.ToString();
            lblNumberOfSpectrometers.Visible = true;
            if (numberOfSpectrometers < 0) // communication error
            {
                lstSpectrometersDiscovered.Items.Clear();
                lstSpectrometersDiscovered.Items.Add("Communication error");
                spectrometerIndex = -1; // set it to an invalid value
                return;
            }
            else if (numberOfSpectrometers == 0) // No spectrometers connected
            {
                lstSpectrometersDiscovered.Items.Clear();
                lstSpectrometersDiscovered.Items.Add("No spectrometers were discovered.");
            }
            else if (numberOfSpectrometers >= 1)
            {
                lstSpectrometersDiscovered.Items.Clear();
            }

            lstSpectrometersDiscovered.Items.Clear();
            for (int i = 0; i <= numberOfSpectrometers - 1; ++i)
            {
                lstSpectrometersDiscovered.Items.Add(wrapper.getName(i) + " " + " s/n" + " " + wrapper.getSerialNumber(i));
            }

            spectrometerIndex = lstSpectrometersDiscovered.SelectedIndex;
        }

        
        private void lstSpectrometersDiscovered_SelectedIndexChanged(object sender, EventArgs e)
        {
         // To not allow user to select a blank row in listbox.
            if ((lstSpectrometersDiscovered.SelectedIndex <= numberOfSpectrometers - 1) && (lstSpectrometersDiscovered.SelectedIndex != -1))
            {
                lstSpectrometersDiscovered.Enabled = false;
                spectrometerIndex = lstSpectrometersDiscovered.SelectedIndex;
                lblSpectrometerSelected.Text = "Selected: " + wrapper.getName(spectrometerIndex) + " s/n " + wrapper.getSerialNumber(spectrometerIndex);
                lblSpectrometerSelected.Visible = true;
            }
            else
            {
                return;
            }
                
         //Check if feature is supported
         short supported;
         String strIsSupported = "Is Internal Trigger Feature Supported? ";

         supported = wrapper.isFeatureSupportedInternalTrigger(spectrometerIndex);
            if (supported == 0) // If not supported
            {
                lblIsFeatureSupported.Text = strIsSupported + "No";
                
            }
            else // If feature is supported, do all this...
            {
                // Get Feature Controller
                internalTriggerWrapper = wrapper.getFeatureControllerInternalTrigger(spectrometerIndex);
                
                lblIsFeatureSupported.Text = strIsSupported + "Yes";

                // set trigger source as internal
                internalTriggerWrapper.setTriggerSource(3);              

                // set internal trigger rate at 0 ms to turn off strobe
                internalTriggerWrapper.setInternalTriggerPeriodMicros(0);

                //Show InternalTrigger controls
                lblGetInternalTriggerPeriodMinimum.Show();
                txtGetInternalTriggerPeriodMinimum.Show();
                lblGetInternalTriggerPeriodMaximum.Show();
                txtGetInternalTriggerPeriodMaximum.Show();
                lblGetInternalTriggerPeriodIncrement.Show();
                txtGetInternalTriggerPeriodIncrement.Show();
                btnGetInternalTriggerPeriodMicros.Show();
                txtGetInternalTriggerPeriodMicros.Show();
                btnSetInternalTriggerPeriodMicros.Show();
                txtSetInternalTriggerPeriodMicros.Show();

                // Populate textboxes
                txtGetInternalTriggerPeriodMicros.Text = internalTriggerWrapper.getInternalTriggerPeriodMicros().ToString();
                txtGetInternalTriggerPeriodMinimum.Text = internalTriggerWrapper.getInternalTriggerPeriodMinimum().ToString();
                txtGetInternalTriggerPeriodMaximum.Text = internalTriggerWrapper.getInternalTriggerPeriodMaximum().ToString();
                txtGetInternalTriggerPeriodIncrement.Text = internalTriggerWrapper.getInternalTriggerPeriodIncrement().ToString();
                
            }
            
             
       }

        private void InternalTrigger_Load(object sender, EventArgs e)
        {

        }

        private void btnGetInternalTriggerPeriodMicros_Click(object sender, EventArgs e)
        {
            txtGetInternalTriggerPeriodMicros.Text = internalTriggerWrapper.getInternalTriggerPeriodMicros().ToString();
        }

        private void btnSetInternalTriggerPeriodMicros_Click(object sender, EventArgs e)
        {
            if (txtSetInternalTriggerPeriodMicros.Text == "" || Convert.ToInt32(txtSetInternalTriggerPeriodMicros.Text) < 0 || Convert.ToInt32(txtSetInternalTriggerPeriodMicros.Text) > 357913941)
            {
                MessageBox.Show("Please enter a value from 0 to 357913941", "Invalid Entry");
            }
            else
            {
            internalTriggerWrapper.setInternalTriggerPeriodMicros(Convert.ToInt32(txtSetInternalTriggerPeriodMicros.Text));
            }

        }

        // To clear application and start over
        private void btnClear_Click(object sender, EventArgs e)
        {
            lblNumberOfSpectrometers.Text = "Number of Spectrometers Discovered: ";
            btnDiscoverSpectrometers.Enabled = true;
            lstSpectrometersDiscovered.Items.Clear();
            lstSpectrometersDiscovered.Enabled = true;
            lblSpectrometerSelected.Text = "Spectrometer Selected: ";
            lblIsFeatureSupported.Text = "Is Internal Trigger Feature Supported?";

            txtGetInternalTriggerPeriodMinimum.Text = "";
            txtGetInternalTriggerPeriodMaximum.Text = "";
            txtGetInternalTriggerPeriodIncrement.Text = "";
            txtGetInternalTriggerPeriodMicros.Text = "";
            txtSetInternalTriggerPeriodMicros.Text = "";

            //Hide InternalTrigger controls
            lblGetInternalTriggerPeriodMinimum.Hide();
            txtGetInternalTriggerPeriodMinimum.Hide();
            lblGetInternalTriggerPeriodMaximum.Hide();
            txtGetInternalTriggerPeriodMaximum.Hide();
            lblGetInternalTriggerPeriodIncrement.Hide();
            txtGetInternalTriggerPeriodIncrement.Hide();
            btnGetInternalTriggerPeriodMicros.Hide();
            txtGetInternalTriggerPeriodMicros.Hide();
            btnSetInternalTriggerPeriodMicros.Hide();
            txtSetInternalTriggerPeriodMicros.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

   
  }            
}
